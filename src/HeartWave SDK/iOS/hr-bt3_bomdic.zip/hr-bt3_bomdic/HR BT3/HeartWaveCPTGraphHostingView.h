//
//  HeartWaveCPTGraphHostingView.h
//  HR BT3
//
//  Created by bomdic on 9/5/13.
//  Copyright (c) 2013 bomdic Coding. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CorePlot-CocoaTouch.h"

@interface HeartWaveCPTGraphHostingView : CPTGraphHostingView <CPTPlotDataSource>{
    NSMutableArray *buffer;
    int counter ;
    BOOL _inverseECG;
}

-(void) initCorePlot;
@property (assign) BOOL inverseECG;
@end
