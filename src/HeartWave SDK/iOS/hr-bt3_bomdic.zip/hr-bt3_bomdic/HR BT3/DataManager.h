//
//  DataManager.h
//  HR BT3
//
//  Created by bomdic on 9/5/13.
//  Copyright (c) 2013 bomdic Coding. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DataManager : NSObject{
    NSMutableData *dataBuffer;
}

@property (nonatomic, retain, readonly) NSMutableArray * heartWaveBuffer;

+ (id)sharedInstance;
- (void) heartWaveDataRecieved:(NSData*)data;


@end

