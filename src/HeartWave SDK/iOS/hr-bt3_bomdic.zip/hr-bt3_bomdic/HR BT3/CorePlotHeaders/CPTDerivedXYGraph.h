#import "CPTXYGraph.h"

@interface CPTDerivedXYGraph : CPTXYGraph {
}

@end
