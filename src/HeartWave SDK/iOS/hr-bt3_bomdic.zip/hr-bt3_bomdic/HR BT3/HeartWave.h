//
//  HeartWave.h
//  HR BT3
//
//  Created by bomdic on 9/5/13.
//  Copyright (c) 2013 bomdic Coding. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HeartWave : NSObject <NSXMLParserDelegate>{
    NSString            *_currentParsingString;
    NSMutableString     *_outstring;
    NSMutableArray      *_HWArray;

    int                 _tag;
    int                 _heartRate;
    BOOL                _signal; // GOOD/BAD
    NSString            *_rri;
    NSString            *_data;
    

}

@property (readonly) int heartRate;


-(id) initWithRawString:(NSString *)rawString;
-(NSNumber*) getY_axisOfHeartWaveAtIndex:(NSUInteger)index;

@end
