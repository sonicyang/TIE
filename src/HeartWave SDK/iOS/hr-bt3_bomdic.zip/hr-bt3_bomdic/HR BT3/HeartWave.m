//
//  HeartWave.m
//  HR BT3
//
//  Created by bomdic on 9/5/13.
//  Copyright (c) 2013 bomdic Coding. All rights reserved.
//

#import "HeartWave.h"
#import "NSData+Base64.h"

@implementation HeartWave

@synthesize heartRate = _heartRate;

-(void) commonInit{
    _heartRate  = 0;
    _signal     = false;
    _rri        = @"--";
    
    _HWArray = [[NSMutableArray alloc] initWithCapacity:255];
    for (int i = 0; i < 255; i++) {
        [_HWArray addObject:[NSNumber numberWithInt:0]];
    }
}


/*
 * Init with Raw string and put into buffer after parsed
 */
- (id) initWithRawString:(NSString *)rawString{
    
    self = [super init];
    if( !self ) return nil;
    
    [self commonInit];
    _outstring = [[NSMutableString alloc] init];
    //    NSLog(@"Data To parse: %@",rawString);
    NSXMLParser *parser = [[NSXMLParser alloc] initWithData:[rawString dataUsingEncoding:NSUTF8StringEncoding]];
    [parser setDelegate: self];
    
    if ([parser parse]) {
         NSLog(@"HeartWave: Parse successful");
    }else{
        NSLog(@"HeartWave: Parse Fail");
    }
    return self;
}



#pragma mark - Parser Delegate
- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName
  namespaceURI:(NSString *)namespaceURI
 qualifiedName:(NSString *)qName
    attributes:(NSDictionary *)attributeDict
{
    if (qName){
        elementName = qName;
    }
	if (elementName)
        _currentParsingString = [NSString stringWithString:elementName];
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName
  namespaceURI:(NSString *)namespaceURI
 qualifiedName:(NSString *)qName
{
    _currentParsingString = nil;
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
	if (!_currentParsingString)
        return;
    
	if ([_currentParsingString isEqualToString:@"D"]){
        
        NSData *data = [string  dataUsingEncoding:NSUTF8StringEncoding];
        data = [data decodeBase64WithString: string];
        if(data.length == 255){
            @try {
                for (int i=0; i<255; i++) {
                    NSData *data1 = [data subdataWithRange:NSMakeRange(i, 1)];
                    
                    unsigned y_value;
                    
                    NSString *hexString = [NSString stringWithFormat:@"%@", data1];
                    
                    hexString = [hexString substringWithRange:NSMakeRange(1, 2)];
                    NSScanner *scan = [NSScanner scannerWithString:hexString];
                    
                    if ([scan scanHexInt:&y_value]) {
                        //                    NSLog(@"Dec value, %d is sccessfully scanned.", dec);
                    } else {
                        NSLog(@"No dec value is scanned.");
                    }
                    
                    [_HWArray replaceObjectAtIndex:i withObject:[[NSNumber alloc] initWithUnsignedInt: y_value]];
                }
                
            }
            @catch (NSException *exception) {
                NSLog(@"Could not parse Heart Wave Data");
            }
        }
        
        _data = string;
        
		[_outstring appendFormat:@"Data: %@\n", string];
        [_outstring appendFormat:@"Data Count: %d\n", [_HWArray count]];
        
        
    }else if ([_currentParsingString isEqualToString:@"S"]){
        if ([string intValue] == 1) {
            _signal = YES; // GOOD
        }else{
            _signal = NO;
        }
        [_outstring appendFormat:@"Signal: %@\n", string];
        
    }else if ([_currentParsingString isEqualToString:@"I"]){
        
        _rri = string;
		[_outstring appendFormat:@"RRI: %@\n", string];
        
    }else if ([_currentParsingString isEqualToString:@"H"]){
		_heartRate = [string intValue];
		[_outstring appendFormat:@"HeartRate: %@\n", string];
    }else if ([_currentParsingString isEqualToString:@"T"]){
        _tag = [string intValue];
		[_outstring appendFormat:@"TAG: %@\n", string];
    }else if ([_currentParsingString isEqualToString:@"Y"]){
		[_outstring appendFormat:@"Battery: %@\n", string];
    }
}


-(void) parserDidStartDocument:(NSXMLParser *)parser {
	//NSLog(@"parserDidStartDocument");
}


//Parse Complete
-(void) parserDidEndDocument: (NSXMLParser *)parser {
    //NSLog(@"HeartWave: parserDidEndDocument...");
}





#pragma mark - Utility

-(NSNumber*) getY_axisOfHeartWaveAtIndex:(NSUInteger)index{
    return [_HWArray objectAtIndex:index%255];
}
@end
