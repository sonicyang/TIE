//
//  RootViewController.m
//  HR BT3
//
//  Created by bomdic on 9/4/13.
//  Copyright (c) 2013 bomdic Coding. All rights reserved.
//

#import <ExternalAccessory/ExternalAccessory.h>

@class EADSessionController;

@interface RootViewController : UITableViewController <UIActionSheetDelegate> {
    NSMutableArray *_accessoryList;

    EAAccessory *_selectedAccessory;
    EADSessionController *_eaSessionController;

    UIActionSheet *_protocolSelectionActionSheet;

    UIView *_noExternalAccessoriesPosterView;
    UILabel *_noExternalAccessoriesLabelView;
}

// from UIActionSheetDelegate
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex;
@end
