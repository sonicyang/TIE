//
//  ViewController.m
//  HR BT3
//
//  Created by bomdic on 9/4/13.
//  Copyright (c) 2013 bomdic Coding. All rights reserved.
//

#import "ViewController.h"
#import "EADSessionController.h"
#import "DataManager.h"
#import "HeartWaveCPTGraphHostingView.h"
#import "HeartWave.h"

@implementation ViewController

@synthesize receivedBytesLabel = _receivedBytesLabel;
@synthesize currentHeartRateLabel = _currentHeartRateLabel;

#pragma mark UIViewController

- (void)viewWillAppear:(BOOL)animated {
    // watch for the accessory being disconnected
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(_accessoryDidDisconnect:) name:EAAccessoryDidDisconnectNotification object:nil];
    // watch for received data from the accessory
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(_sessionDataReceived:) name:EADSessionDataReceivedNotification object:nil];
    
    EADSessionController *sessionController = [EADSessionController sharedController];
    
    _accessory = [sessionController accessory];
    [self setTitle:[sessionController protocolString]];
    [sessionController openSession];
    
    // Core Plot
    HwGraph = [[CPTXYGraph alloc] initWithFrame:self.HeartWaveCorePlot.bounds];
    self.HeartWaveCorePlot.hostedGraph = HwGraph;
    [self.HeartWaveCorePlot initCorePlot];
}

- (void)viewWillDisappear:(BOOL)animated {
    // remove the observers
    [[NSNotificationCenter defaultCenter] removeObserver:self name:EAAccessoryDidConnectNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:EADSessionDataReceivedNotification object:nil];
    
    EADSessionController *sessionController = [EADSessionController sharedController];
    
    [sessionController closeSession];
    _accessory = nil;
}

#pragma mark Internal

- (void)_accessoryDidDisconnect:(NSNotification *)notification {
    if ([[self navigationController] topViewController] == self) {
        EAAccessory *disconnectedAccessory = [[notification userInfo] objectForKey:EAAccessoryKey];
        if ([disconnectedAccessory connectionID] == [_accessory connectionID]) {
            [[self navigationController] popViewControllerAnimated:YES];
        }
    }
}

- (void)_sessionDataReceived:(NSNotification *)notification {
    EADSessionController *sessionController = (EADSessionController *)[notification object];
    uint32_t bytesAvailable = 0;
    
    while ((bytesAvailable = [sessionController readBytesAvailable]) > 0) {
        NSData *data = [sessionController readData:bytesAvailable];
        if (data) {
            _totalBytesRead += bytesAvailable;
            [[DataManager sharedInstance] heartWaveDataRecieved:data];
            [self.HeartWaveCorePlot.hostedGraph reloadData];
        }
    }
    
    [_receivedBytesLabel setText:[NSString stringWithFormat:@"Bytes Received from Session: %d", _totalBytesRead]];
    
    HeartWave *lastHeartRate = [[[DataManager sharedInstance] heartWaveBuffer] lastObject];
    [_currentHeartRateLabel setText:[NSString stringWithFormat:@"Current Heart Rate: %d", lastHeartRate.heartRate]];
}

- (IBAction)inverseECGOnChangeValue:(UISwitch *)sender {
    BOOL state = [sender isOn];
    [self.HeartWaveCorePlot setInverseECG:state];
}
@end
