//
//  ViewController.h
//  HR BT3
//
//  Created by bomdic on 9/4/13.
//  Copyright (c) 2013 bomdic Coding. All rights reserved.
//

#import <ExternalAccessory/ExternalAccessory.h>
#import "CorePlot-CocoaTouch.h"

@class HeartWaveCPTGraphHostingView;
@interface ViewController : UIViewController{
    CPTGraph *HwGraph;

    EAAccessory *_accessory;
    UILabel *_receivedBytesLabel;
    
    uint32_t _totalBytesRead;
}
@property(nonatomic, retain) IBOutlet UILabel *receivedBytesLabel;
@property (strong, nonatomic) IBOutlet UILabel *currentHeartRateLabel;
@property (weak, nonatomic) IBOutlet HeartWaveCPTGraphHostingView *HeartWaveCorePlot;
- (IBAction)inverseECGOnChangeValue:(UISwitch *)sender;

@end
