//
//  HeartWaveCPTGraphHostingView.m
//  HR BT3
//
//  Created by bomdic on 9/5/13.
//  Copyright (c) 2013 bomdic Coding. All rights reserved.
//

#import "HeartWaveCPTGraphHostingView.h"
#import "DataManager.h"
#import "HeartWave.h"

@implementation HeartWaveCPTGraphHostingView 

@synthesize inverseECG = _inverseECG;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

-(void) initCorePlot {
    counter = 0;
    buffer = [[NSMutableArray alloc] initWithCapacity:6];
    
    [buffer addObject:[NSNull null]];
    [buffer addObject:[NSNull null]];
    [buffer addObject:[NSNull null]];
    [buffer addObject:[NSNull null]];
    [buffer addObject:[NSNull null]];
    [buffer addObject:[NSNull null]];
    
    [self configureGraph];
    [self configurePlots];
    [self configureAxes];
}

#pragma mark - CPTPlotDataSource methods
-(NSUInteger)numberOfRecordsForPlot:(CPTPlot *)plot {
	return 255 * 6;
}

-(NSNumber *)numberForPlot:(CPTPlot *)plot field:(NSUInteger)fieldEnum recordIndex:(NSUInteger)index {
    
	NSInteger valueCount = 1530;
    
    
	switch (fieldEnum) {
		case CPTScatterPlotFieldX:{
			if (index < valueCount) {
				return [NSNumber numberWithUnsignedInteger:index];
			}
			break;
        }
		case CPTScatterPlotFieldY:{
            
            if(index >= 255*6)
                break;
            
            if (index == 0) {
                buffer = nil;
                @try {
                    buffer = [[DataManager sharedInstance] heartWaveBuffer];
                }
                @catch (NSException *exception) {
                    NSLog(@"HeartWaveCPT:Fail to getLastSixHeartWaveObjects");
                }
            }
            
            if (buffer == nil || [buffer count] < 6) {
                return nil;
            }
            
            NSNumber *value         = nil;
            HeartWave *hwTemp = [buffer objectAtIndex:index/255];
            
            if ([hwTemp isKindOfClass:[HeartWave class]] && hwTemp != nil) {
                value = [hwTemp getY_axisOfHeartWaveAtIndex:index];
                if (_inverseECG) {
                    NSNumber *invertedValue = [NSNumber numberWithInt:abs(255 - [value intValue])];
                    value = invertedValue;
                }
            }
            
            //Skip to draw the line if the value is zero, avoid to draw lines to zeros when there is no HR data
            if ([value isEqualToNumber:[NSNumber numberWithInt:0]]) {
                return  nil;
            }
            return value;
            
			break;
        }
	}
	return nil;
}


-(void)configureGraph {
	// 1 - Create the graph
	CPTGraph *graph = self.hostedGraph;
    
	[graph applyTheme:[CPTTheme themeNamed:kCPTPlainBlackTheme]];
	// 2 - Set graph title
	// 3 - Create and set text style
	// 4 - Set padding for plot area
    graph.paddingLeft = 5.0;
    graph.paddingTop = 5.0;
    graph.paddingRight = 5.0;
    graph.paddingBottom = 5.0;
	// 5 - Enable user interactions for plot space
	CPTXYPlotSpace *plotSpace = (CPTXYPlotSpace *) graph.defaultPlotSpace;
	plotSpace.allowsUserInteraction = NO;
}

-(void)configurePlots {
	// 1 - Get graph and plot space
	CPTGraph *graph = self.hostedGraph;
	CPTXYPlotSpace *plotSpace = (CPTXYPlotSpace *) graph.defaultPlotSpace;
    
    //2 - Create the heart plot
    CPTScatterPlot *heartPlot = [[CPTScatterPlot alloc] init];
	heartPlot.dataSource = self;
	heartPlot.identifier = @"Heart Rate Plot";
    CPTColor *heartColor = [CPTColor orangeColor];
    [graph addPlot:heartPlot toPlotSpace:plotSpace];
    
    
	// 3 - Set up plot space
	plotSpace.xRange = [CPTPlotRange plotRangeWithLocation:CPTDecimalFromFloat(0.0) length:CPTDecimalFromFloat(255*6)];
	plotSpace.yRange = [CPTPlotRange plotRangeWithLocation:CPTDecimalFromFloat(0.0) length:CPTDecimalFromFloat(255)];
    
    // 4 - Create styles and symbols
    CPTMutableLineStyle *heartlLineStyle = [heartPlot.dataLineStyle mutableCopy];
	heartlLineStyle.lineWidth = 0.5;
	heartlLineStyle.lineColor = heartColor;
	heartPlot.dataLineStyle = heartlLineStyle;
	CPTMutableLineStyle *heartSymbolLineStyle = [CPTMutableLineStyle lineStyle];
	heartSymbolLineStyle.lineColor = heartColor;
	CPTPlotSymbol *heartSymbol = [CPTPlotSymbol ellipsePlotSymbol];
	heartSymbol.fill = [CPTFill fillWithColor:heartColor];
	heartSymbol.lineStyle = heartlLineStyle;
	heartSymbol.size = CGSizeMake(0.1f, 0.1f);
	heartPlot.plotSymbol = heartSymbol;
}





-(void)configureAxes {
    
	// 1 - Create styles
	CPTMutableTextStyle *axisTitleStyle = [CPTMutableTextStyle textStyle];
	axisTitleStyle.color = [CPTColor blackColor];
	axisTitleStyle.fontName = @"Helvetica-Bold";
	axisTitleStyle.fontSize = 10.0f;
	CPTMutableLineStyle *axisLineStyle = [CPTMutableLineStyle lineStyle];
	axisLineStyle.lineWidth = 2.0f;
	axisLineStyle.lineColor = [CPTColor blackColor];
	CPTMutableTextStyle *axisTextStyle = [[CPTMutableTextStyle alloc] init];
	axisTextStyle.color = [CPTColor blackColor];
	axisTextStyle.fontName = @"Helvetica-Bold";
	axisTextStyle.fontSize = 10.0f;
	CPTMutableLineStyle *tickLineStyle = [CPTMutableLineStyle lineStyle];
	tickLineStyle.lineColor = [CPTColor blackColor];
	tickLineStyle.lineWidth = 2.0f;
	CPTMutableLineStyle *gridLineStyle = [CPTMutableLineStyle lineStyle];
	tickLineStyle.lineColor = [CPTColor blackColor];
	tickLineStyle.lineWidth = 1.0f;
	
    // 2 - Get axis set
	CPTXYAxisSet *axisSet = (CPTXYAxisSet *) self.hostedGraph.axisSet;
	
    // 3 - Configure x-axis
	CPTAxis *x = axisSet.xAxis;
	x.title = @"Seconds";
	x.titleTextStyle = axisTitleStyle;
	x.titleOffset = 15.0f;
	x.axisLineStyle = axisLineStyle;
	x.labelingPolicy = CPTAxisLabelingPolicyNone;
	x.labelTextStyle = axisTextStyle;
	x.majorTickLineStyle = axisLineStyle;
	x.majorTickLength = 4.0f;
	x.tickDirection = CPTSignNegative;
	CGFloat dateCount = 255*6;
	NSMutableSet *xLabels = [NSMutableSet setWithCapacity:dateCount];
	NSMutableSet *xLocations = [NSMutableSet setWithCapacity:dateCount];
	
    
    //NSInteger i = 0;
    int second = 1;
    for (second=1; second<=255*6; second+=255) {
		CPTAxisLabel *label = [[CPTAxisLabel alloc] initWithText:[NSString stringWithFormat:@"%d",second/255]  textStyle:x.labelTextStyle];
		CGFloat location = second;
		label.tickLocation = CPTDecimalFromCGFloat(location);
		label.offset = x.majorTickLength;
		if (label) {
			[xLabels addObject:label];
			[xLocations addObject:[NSNumber numberWithFloat:location]];
		}
    }
    
	x.axisLabels = xLabels;
	x.majorTickLocations = xLocations;
	
    // 4 - Configure y-axis
	CPTAxis *y = axisSet.yAxis;
	y.title = @" ";
	y.titleTextStyle = axisTitleStyle;
	y.titleOffset = -40.0f;
	y.axisLineStyle = axisLineStyle;
	y.majorGridLineStyle = gridLineStyle;
	y.labelingPolicy = CPTAxisLabelingPolicyNone;
	y.labelTextStyle = axisTextStyle;
	y.labelOffset = 16.0f;
	y.majorTickLineStyle = axisLineStyle;
	y.majorTickLength = 4.0f;
	y.minorTickLength = 2.0f;
	y.tickDirection = CPTSignPositive;
	NSInteger majorIncrement = 128;
	NSInteger minorIncrement = 64;
	CGFloat yMax = 256.0f;  // should determine dynamically based on max price
	NSMutableSet *yLabels = [NSMutableSet set];
	NSMutableSet *yMajorLocations = [NSMutableSet set];
	NSMutableSet *yMinorLocations = [NSMutableSet set];
	for (NSInteger j = minorIncrement; j <= yMax; j += minorIncrement) {
		NSUInteger mod = j % majorIncrement;
		if (mod == 0) {
			CPTAxisLabel *label = [[CPTAxisLabel alloc] initWithText:[NSString stringWithFormat:@"%i", j] textStyle:y.labelTextStyle];
			NSDecimal location = CPTDecimalFromInteger(j);
			label.tickLocation = location;
			label.offset = -y.majorTickLength - y.labelOffset;
			if (label) {
				[yLabels addObject:label];
			}
			[yMajorLocations addObject:[NSDecimalNumber decimalNumberWithDecimal:location]];
		} else {
			[yMinorLocations addObject:[NSDecimalNumber decimalNumberWithDecimal:CPTDecimalFromInteger(j)]];
		}
	}
	y.axisLabels = yLabels;
	y.majorTickLocations = yMajorLocations;
	y.minorTickLocations = yMinorLocations;
    
}


@end