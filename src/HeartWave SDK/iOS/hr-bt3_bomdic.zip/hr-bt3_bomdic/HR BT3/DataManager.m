//
//  DataManager.m
//  HR BT3
//
//  Created by bomdic on 9/5/13.
//  Copyright (c) 2013 bomdic Coding. All rights reserved.
//

#import "DataManager.h"
#import "HeartWave.h"

@implementation DataManager{
    NSData *beginTag;
    NSData *endTag;
}

@synthesize heartWaveBuffer = _heartWaveBuffer;



+ (id)sharedInstance {
    static dispatch_once_t p = 0;
    __strong static id _sharedObject = nil;
    dispatch_once(&p, ^{
        _sharedObject = [[self alloc] init];
    });
    return _sharedObject;
}

- (id)init {
    self =[super init];
    if (self) {
        _heartWaveBuffer    = [NSMutableArray new];
        dataBuffer        = [NSMutableData new];
        
        beginTag  = [@"<B>" dataUsingEncoding:NSUTF8StringEncoding];
        endTag   = [@"</B>" dataUsingEncoding:NSUTF8StringEncoding];
    }
    return self;
}


-(void) heartWaveDataRecieved:(NSData*)data;{
    [dataBuffer appendData:data];
    
    NSRange endTagFound  = [dataBuffer rangeOfData:endTag options:NSDataSearchBackwards range:NSMakeRange(0, [dataBuffer length])];

    if (endTagFound.location != NSNotFound) {  // IF end tag is found
        
        NSRange beginTagFound = [dataBuffer rangeOfData:beginTag options:NSDataSearchBackwards range:NSMakeRange(0, endTagFound.location)];
        
        if (beginTagFound.location != NSNotFound) { // if begin tag is found before a end tag
            NSData *onePackageData = [dataBuffer subdataWithRange:NSMakeRange(beginTagFound.location, endTagFound.location+endTagFound.length -beginTagFound.location)];
            NSString* dataAsString = [NSString stringWithCString:[onePackageData bytes] encoding:NSUTF8StringEncoding];
            [[self heartWaveBuffer] addObject:[[HeartWave alloc] initWithRawString:dataAsString]];
            NSLog(@"%@",dataAsString);
        }
        [dataBuffer replaceBytesInRange:NSMakeRange(0, endTagFound.location + endTagFound.length) withBytes:NULL length:0];
    }
}

// HeartWaveBuffer getter
- (NSMutableArray *) heartWaveBuffer{
    if (_heartWaveBuffer.count > 6) {
        [_heartWaveBuffer removeObjectAtIndex:0];
    }
    NSLog(@"count %d", _heartWaveBuffer.count);
    return _heartWaveBuffer;
}

@end
